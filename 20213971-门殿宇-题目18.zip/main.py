import re
import tkinter as tk
from tkinter import messagebox, filedialog

# 生成窗口，定义窗口标题，大小，显示位置
window = tk.Tk()
window.title('学生成绩管理系统')
window.geometry('200x300+600+200')


# 学生类，定义学生属性及方法
class Student:
    def __init__(self, student_id, student_name, student_class):
        # 学号
        self.student_id = student_id
        # 姓名
        self.student_name = student_name
        # 班级
        self.student_class = student_class

    # 拼接学生信息
    def to_string(self):
        return f"学号：{self.student_id}\n姓名：{self.student_name}\n班级：{self.student_class}"


# 课程类，定义课程属性及方法
class Course:
    def __init__(self, course_id, course_name, course_credit):
        # 课程号
        self.course_id = course_id
        # 课程名
        self.course_name = course_name
        # 学分
        self.course_credit = course_credit

    # 拼接课程信息
    def to_string(self):
        return f"课程号：{self.course_id}\n课程名：{self.course_name}\n学分：{self.course_credit}"


# 成绩类，定义成绩属性和方法
class Score:
    def __init__(self, student_id, course_id, grade):
        self.student_id = student_id
        self.course_id = course_id
        self.grade = grade

    # 拼接课程信息
    def to_string(self):
        return f"学号：{self.student_id}\n课程号：{self.course_id}\n成绩：{self.grade}"


class GradeManagement:
    def __init__(self):
        # 存储学生信息
        self.students = []
        # 存储课程信息
        self.courses = []
        # 存储成绩信息
        self.scores = []

    # 将学生信息添加到学生数组中
    def add_student(self, student):
        self.students.append(student)

    # 将课程信息添加到课程数组中
    def add_course(self, course):
        self.courses.append(course)

    # 将成绩信息添加到课程数组中
    def add_score(self, score):
        self.scores.append(score)

    def save_data(self):
        # 将添加的学生信息写入文件
        with open("students.txt", "w") as f:
            for student in self.students:
                f.write(student.to_string())
                f.write("\n---\n")
        # 将添加的课程信息写入文件
        with open("courses.txt", "w") as f:
            for course in self.courses:
                f.write(course.to_string())
                f.write("\n---\n")
        # 将添加的成绩信息写入文件
        with open("grades.txt", "w") as f:
            for score in self.scores:
                f.write(score.to_string())
                f.write("\n---\n")

    # 加载文件中的数据
    def load_data(self):
        try:
            with open("students.txt", "r") as f:
                # 读取文件内容并按 "---" 分隔为多个学生信息
                data = f.read().split("---")
                # 遍历每个学生信息
                for item in data:
                    # 去除前后空白字符并按行拆分为列表
                    student_data = item.strip().split("\n")
                    # 确保学生信息完整
                    if len(student_data) == 3:
                        # 解析学生信息
                        student_id = student_data[0].split("：")[1]  # 学号
                        student_name = student_data[1].split("：")[1]  # 姓名
                        student_class = student_data[2].split("：")[1]  # 班级
                        # 创建学生对象
                        student = Student(student_id, student_name, student_class)
                        # 将学生对象添加到学生列表
                        self.students.append(student)
            with open("courses.txt", "r") as f:
                data = f.read().split("---")
                for item in data:
                    course_data = item.strip().split("\n")
                    if len(course_data) == 3:
                        course_id = course_data[0].split("：")[1]  # 课程号
                        course_name = course_data[1].split("：")[1]  # 课程名
                        credit = course_data[2].split("：")[1]  # 学分
                        course = Course(course_id, course_name, credit)
                        self.courses.append(course)
            with open("grades.txt", "r") as f:
                data = f.read().split("---")
                for item in data:
                    grade_data = item.strip().split("\n")
                    if len(grade_data) == 3:
                        student_id = grade_data[0].split("：")[1]
                        course_id = grade_data[1].split("：")[1]
                        score = grade_data[2].split("：")[1]
                        grade = Score(student_id, course_id, score)
                        self.scores.append(grade)
        except FileNotFoundError:
            # 如果文件不存在，显示警告对话框
            messagebox.showwarning("警告", "数据文件不存在，请先添加数据")


grade_management = GradeManagement()


# 学生管理
def students_management():
    # 添加学生功能
    def add_student():
        # 获取输入信息
        student_id = student_id_entry.get()
        student_name = student_name_entry.get()
        student_class = student_class_entry.get()

        # 验证学号是否存在
        student_ids = [student.student_id for student in grade_management.students]

        if student_id in student_ids:
            messagebox.showwarning("警告", "学号已存在")
            return
        if len(student_id) != 8:
            messagebox.showwarning("警告", "学号位数有误")
            student_id_entry.focus()
            return
        # 生成学生对象
        student = Student(student_id, student_name, student_class)
        # 将学生信息添加到学生列表
        grade_management.add_student(student)
        # 将列表中信息写入文件
        grade_management.save_data()
        messagebox.showinfo("提示", "添加学生成功")
        student_window.destroy()

    student_window = tk.Toplevel(window)
    student_window.title("学生管理")
    student_window.geometry("300x200+600+200")
    # 学号标签
    student_id_label = tk.Label(student_window, text='学号')
    student_id_label.grid(row=0, column=0, padx=10, pady=10)
    # 学号输入框
    student_id_entry = tk.Entry(student_window)
    student_id_entry.grid(row=0, column=1, padx=10, pady=10)
    # 光标聚焦学号输入框
    student_id_entry.focus()
    # 姓名标签
    student_name_label = tk.Label(student_window, text='姓名')
    student_name_label.grid(row=1, column=0, padx=10, pady=10)
    # 姓名输入框
    student_name_entry = tk.Entry(student_window)
    student_name_entry.grid(row=1, column=1, padx=10, pady=10)
    # 班级标签
    student_class_label = tk.Label(student_window, text='班级')
    student_class_label.grid(row=2, column=0, padx=10, pady=10)
    # 班级输入框
    student_class_entry = tk.Entry(student_window)
    student_class_entry.grid(row=2, column=1, padx=10, pady=10)
    # 创建框架
    button_frame = tk.Frame(student_window)
    button_frame.grid(row=3, column=0, columnspan=2, pady=10)

    # 取消按钮
    cancel_button = tk.Button(button_frame, text='取消', command=student_window.destroy)
    cancel_button.pack(side=tk.LEFT, padx=10)
    # 添加按钮
    add_student_button = tk.Button(button_frame, text='添加学生', command=add_student)
    add_student_button.pack(side=tk.LEFT, padx=10)


# 课程管理
def courses_management():
    # 添加课程功能
    def add_course():
        # 获取输入信息
        course_id = course_id_entry.get()
        course_name = course_name_entry.get()
        course_credit = course_credit_entry.get()
        # 验证课程号是否存在
        course_ids = [course.course_id for course in grade_management.courses]

        if course_id in course_ids:
            messagebox.showwarning("警告", "课程号已存在")
            return

        # 生成课程对象
        course = Course(course_id, course_name, course_credit)
        # 将课程信息添加到课程列表
        grade_management.add_course(course)
        # 将列表中信息写入文件
        grade_management.save_data()
        messagebox.showinfo("提示", "添加课程成功")
        course_window.destroy()

    course_window = tk.Toplevel(window)
    course_window.title("课程管理")
    course_window.geometry("300x200+600+200")
    # 课程号标签
    course_id_label = tk.Label(course_window, text='课程号')
    course_id_label.grid(row=0, column=0, padx=10, pady=10)
    # 课程号输入框
    course_id_entry = tk.Entry(course_window)
    course_id_entry.grid(row=0, column=1, padx=10, pady=10)
    # 光标聚焦课程号输入框
    course_id_entry.focus()
    # 课程名标签
    course_name_label = tk.Label(course_window, text='课程名')
    course_name_label.grid(row=1, column=0, padx=10, pady=10)
    # 课程名输入框
    course_name_entry = tk.Entry(course_window)
    course_name_entry.grid(row=1, column=1, padx=10, pady=10)
    # 学分标签
    course_credit_label = tk.Label(course_window, text='学分')
    course_credit_label.grid(row=2, column=0, padx=10, pady=10)
    # 学分输入框
    course_credit_entry = tk.Entry(course_window)
    course_credit_entry.grid(row=2, column=1, padx=10, pady=10)
    # 创建框架
    button_frame = tk.Frame(course_window)
    button_frame.grid(row=3, column=0, columnspan=2, pady=10)
    # 取消按钮
    cancel_button = tk.Button(button_frame, text='取消', command=course_window.destroy)
    cancel_button.pack(side=tk.LEFT, padx=10)
    # 添加按钮
    add_course_button = tk.Button(button_frame, text='添加课程', command=add_course)
    add_course_button.pack(side=tk.LEFT, padx=10)


def scores_management():
    # 查询成绩
    def search():
        search_text = search_entry.get()
        # 清空之前的结果
        listbox.delete(0, tk.END)
        # 储存成绩信息
        results = []
        # 当输入为学号或课程号时
        if search_text:
            results += [grade for grade in grade_management.scores if
                        grade.student_id == search_text or grade.course_id == search_text]
        # 当输入为班级时
        if search_text:
            results += [grade for grade in grade_management.scores if
                        grade.student_id in [student.student_id for student in grade_management.students if
                                             student.student_class == search_text]]
        # 检查查询结果是否为空
        if not results:
            messagebox.showinfo("查询结果", "未找到匹配的成绩")
        else:
            # 根据成绩进行降序排序排序
            sorted_results = sorted(results, key=lambda grade: grade.grade, reverse=True)
            # 清空之前的结果
            listbox.delete(0, tk.END)
            # 将查询结果插入到Listbox中
            for result in sorted_results:
                display_text = f"学号: {result.student_id}, 课程号: {result.course_id}, 成绩: {result.grade}"
                listbox.insert(tk.END, display_text)

    def add_window():
        add_window = tk.Toplevel(score_window)
        add_window.title("添加成绩")
        add_window.geometry('300x200+600+200')

        # 学号标签
        student_id_label = tk.Label(add_window, text='学号')
        student_id_label.grid(row=0, column=0, padx=10, pady=10)
        # 学号输入框
        student_id_entry = tk.Entry(add_window)
        student_id_entry.grid(row=0, column=1, padx=10, pady=10)
        student_id_entry.focus()

        # 课程号标签
        course_id_label = tk.Label(add_window, text='课程号')
        course_id_label.grid(row=1, column=0, padx=10, pady=10)
        # 课程号输入框
        course_id_entry = tk.Entry(add_window)
        course_id_entry.grid(row=1, column=1, padx=10, pady=10)

        # 成绩标签
        grade_label = tk.Label(add_window, text='成绩')
        grade_label.grid(row=2, column=0, padx=10, pady=10)
        # 成绩输入框
        grade_entry = tk.Entry(add_window)
        grade_entry.grid(row=2, column=1, padx=10, pady=10)

        # 创建框架
        button_frame = tk.Frame(add_window)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        # 取消按钮
        cancel_button = tk.Button(button_frame, text='取消', command=add_window.destroy)
        cancel_button.pack(side=tk.LEFT, padx=10)

        def add_score():
            # 获取输入
            student_id = student_id_entry.get()
            course_id = course_id_entry.get()
            grade = int(grade_entry.get())
            # 验证成绩是否合法
            if grade < 0 or grade > 100:
                messagebox.showwarning("警告", "成绩错误")
                grade_entry.focus()
                return
            # 验证学号和课程号是否存在
            student_ids = [student.student_id for student in grade_management.students]
            course_ids = [course.course_id for course in grade_management.courses]

            if student_id not in student_ids:
                messagebox.showwarning("警告", "学号不存在")
                student_id_entry.focus()
                return

            if course_id not in course_ids:
                messagebox.showwarning("警告", "课程号不存在")
                course_id_entry.focus()
                return

            # 检查某学生某门成绩是否已存在
            for existing_score in grade_management.scores:
                if existing_score.student_id == student_id and existing_score.course_id == course_id:
                    messagebox.showwarning("警告", "该学生该科成绩已存在")
                    return

            # 生成成绩对象
            score = Score(student_id, course_id, grade)
            # 将成绩信息添加到成绩数组
            grade_management.add_score(score)
            # 将数组中信息写入文件
            grade_management.save_data()

            messagebox.showinfo("提示", "添加成绩成功")
            add_window.destroy()

        # 添加按钮
        add_score_button = tk.Button(button_frame, text='添加成绩', command=add_score)
        add_score_button.pack(side=tk.LEFT, padx=10)

    def show_details(event):
        selected_index = listbox.curselection()
        if not selected_index:
            return

        selected_text = listbox.get(selected_index[0])
        student_id = re.search(r"学号: (\d+)", selected_text)
        course_id = re.search(r"课程号: (\d+)", selected_text)
        if student_id and course_id:
            student_id = student_id.group(1)
            course_id = course_id.group(1)

            for score in grade_management.scores:
                if score.student_id == student_id and score.course_id == course_id:
                    details_window = tk.Toplevel(score_window)
                    details_window.title("成绩详情")
                    details_window.geometry("200x120+600+200")

                    student_id_label = tk.Label(details_window, text=f"学    号: {score.student_id}")
                    student_id_label.grid(row=0, column=0, sticky="W")

                    course_id_label = tk.Label(details_window, text=f"课程号: {score.course_id}")
                    course_id_label.grid(row=1, column=0, sticky="W")

                    grade_label = tk.Label(details_window, text=f"成    绩: {score.grade}")
                    grade_label.grid(row=2, column=0, sticky="W")

                    # 添加修改按钮和删除按钮
                    edit_button = tk.Button(details_window, text="修改", command=lambda: edit_score(score))
                    edit_button.grid(row=3, column=0, padx=10, pady=10, sticky=tk.W)

                    delete_button = tk.Button(details_window, text="删除", command=lambda: delete_score(score))
                    delete_button.grid(row=3, column=1, pady=10, sticky=tk.E)
                    break

        def delete_score(score):

            # 弹出提示框，询问是否删除成绩
            answer = messagebox.askyesno("删除", "是否删除该成绩记录？")
            if answer:
                # 删除成绩信息
                grade_management.scores.remove(score)
                details_window.destroy()

                # 将删除后的信息写入文件
                grade_management.save_data()

                # 刷新成绩列表
                search()

        # 修改成绩
        def edit_score(score):

            # 初始化修改成绩窗口
            edit_window = tk.Toplevel(score_window)
            edit_window.title("修改成绩")
            edit_window.geometry("300x200+600+200")
            # 学号标签
            student_id_label = tk.Label(edit_window, text='学号')
            student_id_label.grid(row=0, column=0, padx=10, pady=10)
            # 学号输入框
            student_id_entry = tk.Entry(edit_window)
            # 设置默认内容
            student_id_entry.insert(0, student_id)
            student_id_entry.grid(row=0, column=1, padx=10, pady=10)

            # 课程号标签
            course_id_label = tk.Label(edit_window, text='课程号')
            course_id_label.grid(row=1, column=0, padx=10, pady=10)
            # 课程号输入框
            course_id_entry = tk.Entry(edit_window)
            course_id_entry.insert(0, course_id)
            course_id_entry.grid(row=1, column=1, padx=10, pady=10)

            # 成绩标签
            grade_label = tk.Label(edit_window, text='成绩')
            grade_label.grid(row=2, column=0, padx=10, pady=10)
            # 成绩输入框
            grade_entry = tk.Entry(edit_window)
            grade_entry.grid(row=2, column=1, padx=10, pady=10)
            grade_entry.focus()
            # 创建框架
            button_frame = tk.Frame(edit_window)
            button_frame.grid(row=3, column=0, columnspan=2, pady=10)

            # 修改成绩
            def save_score():

                # 获取修改后的成绩信息
                student_id = student_id_entry.get()
                course_id = course_id_entry.get()
                score_value = grade_entry.get()

                # 在成绩列表中查找对应的成绩对象
                # index获取索引，s获取对应值
                for index, s in enumerate(grade_management.scores):
                    if s.student_id == score.student_id and s.course_id == score.course_id:
                        grade_management.scores[index].student_id = student_id
                        grade_management.scores[index].course_id = course_id
                        grade_management.scores[index].grade = score_value
                        grade_management.save_data()
                        search()
                        messagebox.showinfo("提示", "修改成功")
                        edit_window.destroy()
                        details_window.destroy()
                        return

                # 如果未找到对应的成绩对象，显示错误提示
                messagebox.showerror("错误", "未找到对应的成绩信息！")

            # 取消按钮
            cancel_button = tk.Button(button_frame, text='取消', command=edit_window.destroy)
            cancel_button.pack(side=tk.LEFT, padx=10)
            # 保存按钮
            save_button = tk.Button(button_frame, text='保存', command=save_score)
            save_button.pack(side=tk.LEFT, padx=10)

    score_window = tk.Toplevel(window)
    score_window.title('成绩管理')
    score_window.geometry("300x200+600+200")

    # 搜索框
    search_frame = tk.Frame(score_window)
    search_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

    # "搜索："标签
    search_label = tk.Label(search_frame, text="搜索：")
    search_label.pack(side=tk.LEFT)

    # 输入框
    search_entry = tk.Entry(search_frame)
    search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
    search_entry.focus()

    # 按钮框架
    button_frame = tk.Frame(score_window)
    button_frame.pack()
    # 取消按钮
    cancel_button = tk.Button(button_frame, text='取消', command=score_window.destroy)
    cancel_button.pack(side=tk.LEFT)
    # 查询按钮
    search_button = tk.Button(button_frame, text='查询', command=search)
    search_button.pack(side=tk.LEFT)
    # 添加按钮
    add_button = tk.Button(button_frame, text='添加成绩', command=add_window)
    add_button.pack(side=tk.LEFT)

    # 结果显示框架
    show_frame = tk.Frame(score_window)
    show_frame.pack(fill=tk.BOTH, expand=True)

    listbox = tk.Listbox(show_frame)
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # 将列表中的每个项目绑定到 show_details 方法，双击展示详细信息
    listbox.bind("<Double-Button-1>", show_details)
    # 设置滚动条，滚动显示列表
    scrollbar = tk.Scrollbar(show_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)


def scores_search():
    # 查询成绩
    def search():
        search_text = search_entry.get()
        # 储存成绩信息
        results = []
        # 当输入为学号或课程号时
        if search_text:
            results += [grade for grade in grade_management.scores if
                        grade.student_id == search_text or grade.course_id == search_text]
        # 当输入为班级时
        if search_text:
            results += [grade for grade in grade_management.scores if
                        grade.student_id in [student.student_id for student in grade_management.students if
                                             student.student_class == search_text]]
        # 检查查询结果是否为空
        if not results:
            messagebox.showinfo("查询结果", "未找到匹配的成绩")
            search_entry.focus()
        else:
            # 根据成绩进行排序
            sorted_results = sorted(results, key=lambda grade: grade.grade, reverse=True)
            # 清空之前的结果
            listbox.delete(0, tk.END)
            # 将查询结果插入到Listbox中
            for result in sorted_results:
                display_text = f"学号: {result.student_id}, 课程号: {result.course_id}, 成绩: {result.grade}"
                listbox.insert(tk.END, display_text)

    # 结果保存到文件
    def save_results():
        # 借助文件对话框，将结果保存到文件，可自定文件名，文件类型默认为.txt
        file_path = filedialog.asksaveasfilename(defaultextension=".txt")
        if file_path:
            # 将查询结果列表中的内容写入文件
            with open(file_path, "w") as f:
                for i in range(listbox.size()):
                    f.write(listbox.get(i) + "\n")
            messagebox.showinfo("保存成功", "查询结果已保存到文件")

    search_window = tk.Toplevel(window)
    search_window.title('成绩查询')
    search_window.geometry("300x350+600+200")
    # "搜索："标签
    label = tk.Label(search_window, text="可根据学号/课程号/班级查询")
    label.pack(pady=5)
    # 搜索框
    search_frame = tk.Frame(search_window)
    search_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=10)

    # "搜索："标签
    search_label = tk.Label(search_frame, text="搜索：")
    search_label.pack(side=tk.LEFT)

    # 输入框
    search_entry = tk.Entry(search_frame)
    search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
    search_entry.focus()

    # 按钮框架
    button_frame = tk.Frame(search_window)
    button_frame.pack()
    # 取消按钮
    cancel_button = tk.Button(button_frame, text='取消', command=search_window.destroy)
    cancel_button.pack(side=tk.LEFT)
    # 查询按钮
    search_button = tk.Button(button_frame, text='查询成绩', command=search)
    search_button.pack(side=tk.LEFT)
    # 保存到文件按钮
    save_button = tk.Button(button_frame, text='导出', command=save_results)
    save_button.pack(side=tk.LEFT)
    # 结果显示框架
    show_frame = tk.Frame(search_window)
    show_frame.pack(fill=tk.BOTH, expand=True)

    listbox = tk.Listbox(show_frame)
    listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    scrollbar = tk.Scrollbar(show_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)


students_label = tk.Label(window, text='主菜单', font=("song", 17))
students_label.pack(pady=10)
# 学生管理按钮
students_Button = tk.Button(window, text='学生管理', command=students_management)
students_Button.pack(pady=10)
# 课程管理按钮
courses_Button = tk.Button(window, text='课程管理', command=courses_management)
courses_Button.pack(pady=10)
# 成绩管理按钮
scores_Button = tk.Button(window, text='成绩管理', command=scores_management)
scores_Button.pack(pady=10)
# 成绩查询按钮
search_Button = tk.Button(window, text='成绩查询', command=scores_search)
search_Button.pack(pady=10)

# 加载已保存的数据
grade_management.load_data()

window.mainloop()
